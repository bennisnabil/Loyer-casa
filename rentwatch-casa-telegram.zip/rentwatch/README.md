# 🏙️ RentWatch Casa — Agent de Veille Immobilière

Agent Python qui scrape **Avito.ma, Mubawab.ma et Sarouty.ma** toutes les 30 minutes
et t'envoie une alerte **WhatsApp** dès qu'une nouvelle annonce correspond à tes critères.

---

## 🎯 Critères configurés

| Paramètre | Valeur |
|-----------|--------|
| Budget | 3 000 – 6 000 MAD/mois |
| Type | Appartement |
| Quartiers | Maarif, Gauthier, Hay Riad, Anfa, Centre-ville, Racine |
| Fréquence | Toutes les 30 minutes |
| Alerte | WhatsApp (Meta Business API) |

---

## 🚀 Déploiement sur Railway (recommandé — gratuit)

### Étape 1 — Préparer WhatsApp Business API

1. Va sur [developers.facebook.com](https://developers.facebook.com)
2. Crée une application → type **"Business"**
3. Ajoute le produit **"WhatsApp"**
4. Dans *WhatsApp > Getting Started*, note :
   - **Token d'accès temporaire** (ou crée un System User pour un token permanent)
   - **Phone Number ID**
5. Dans *WhatsApp > Configuration*, ajoute ton numéro en tant que numéro de test
6. Ton numéro doit être au format : `212612345678` (sans `+`)

### Étape 2 — Déployer sur Railway

1. Crée un compte sur [railway.app](https://railway.app) (gratuit, 5$/mois après 500h)
2. Clique sur **"New Project" → "Deploy from GitHub repo"**
3. Upload ce dossier sur GitHub (ou utilise **"Deploy from local"**)
4. Dans Railway, va dans **Settings > Variables** et ajoute :

```
BUDGET_MIN        = 3000
BUDGET_MAX        = 6000
QUARTIERS         = maarif,gauthier,hay-riad,anfa,centre-ville,racine
SCAN_INTERVAL     = 30
WHATSAPP_TOKEN    = <ton token Meta>
WHATSAPP_PHONE_ID = <ton Phone Number ID>
WHATSAPP_TO       = 212XXXXXXXXX
```

5. Railway détecte automatiquement le `Procfile` et démarre l'agent.
6. Vérifie les logs dans l'onglet **"Deployments"** — tu dois voir :
   ```
   🚀 RentWatch Casa — Agent démarré
   🔍 Scan démarré...
   ✅ Scan terminé
   ```

### Étape 3 — Tester

Dans le terminal Railway ou localement :
```bash
pip install -r requirements.txt
cp .env.example .env   # remplis les valeurs
python agent.py
```

---

## 📱 Format du message WhatsApp reçu

```
🏠 Nouvelle annonce — RentWatch Casa

📍 Appartement lumineux F3 — Maarif
💰 5 500 MAD/mois
📌 Quartier : Maarif
🕐 Détectée à : 14/04 09:32
📡 Source : Avito.ma

🔗 https://www.avito.ma/...
```

---

## ⚙️ Personnalisation

Modifie les variables dans `.env.example` (ou Railway Variables) :

- `BUDGET_MIN` / `BUDGET_MAX` — adapter le budget
- `QUARTIERS` — ajouter/retirer des quartiers (séparés par virgule)
- `SCAN_INTERVAL` — changer la fréquence (minimum recommandé : 15 min)

---

## 🔧 Structure du projet

```
rentwatch/
├── agent.py          # Script principal (scraping + alertes)
├── requirements.txt  # Dépendances Python
├── Procfile          # Commande de démarrage Railway/Heroku
├── railway.json      # Config Railway
├── .env.example      # Template variables d'environnement
└── README.md         # Ce fichier
```

---

## ⚠️ Notes importantes

- Les sélecteurs HTML des sites peuvent changer si les sites mettent à jour leur structure.
  Dans ce cas, il faut inspecter la page et adapter les sélecteurs CSS dans `agent.py`.
- Le fichier `seen_listings.json` garde en mémoire les annonces déjà vues pour éviter les doublons.
  Sur Railway, ce fichier est réinitialisé à chaque redéploiement (comportement normal).
- Pour un token WhatsApp permanent, crée un **System User** dans Meta Business Manager.

---

*Construit pour Gibraltar Consulting — Nabil*
