"""
RentWatch Casa — Agent de veille immobilière Casablanca
Scrape Avito.ma, Mubawab.ma, Sarouty.ma toutes les 30 minutes
et envoie une alerte Telegram pour chaque nouvelle annonce.
"""

import os
import time
import json
import hashlib
import logging
import schedule
import requests
from bs4 import BeautifulSoup
from datetime import datetime

# ─── LOGGING ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
log = logging.getLogger("RentWatch")

# ─── CONFIG ──────────────────────────────────────────────────────────────────

CONFIG = {
    "budget_min": int(os.getenv("BUDGET_MIN", 3000)),
    "budget_max": int(os.getenv("BUDGET_MAX", 6000)),
    "type_bien":  os.getenv("TYPE_BIEN", "appartement"),
    "quartiers":  os.getenv("QUARTIERS", "maarif,gauthier,hay-riad,anfa,centre-ville,racine").split(","),
    "telegram_token":   os.getenv("TELEGRAM_TOKEN", ""),
    "telegram_chat_id": os.getenv("TELEGRAM_CHAT_ID", ""),
    "scan_interval_min": int(os.getenv("SCAN_INTERVAL", 30)),
    "seen_file": "seen_listings.json",
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "fr-FR,fr;q=0.9",
}

# ─── SEEN LISTINGS (persistance locale) ──────────────────────────────────────

def load_seen():
    if os.path.exists(CONFIG["seen_file"]):
        with open(CONFIG["seen_file"]) as f:
            return set(json.load(f))
    return set()

def save_seen(seen: set):
    with open(CONFIG["seen_file"], "w") as f:
        json.dump(list(seen), f)

def listing_id(url: str) -> str:
    return hashlib.md5(url.encode()).hexdigest()

# ─── SCRAPERS ────────────────────────────────────────────────────────────────

def scrape_avito() -> list[dict]:
    """Scrape Avito.ma — location appartements Casablanca"""
    results = []
    for quartier in CONFIG["quartiers"]:
        url = (
            f"https://www.avito.ma/fr/casablanca/appartements-"
            f"%C3%A0_louer?pr={CONFIG['budget_min']},{CONFIG['budget_max']}"
            f"&q={quartier}"
        )
        try:
            r = requests.get(url, headers=HEADERS, timeout=15)
            r.raise_for_status()
            soup = BeautifulSoup(r.text, "html.parser")

            # Sélecteurs Avito (susceptibles de changer si le site évolue)
            cards = soup.select("article.sc-1nre5ec-1, li[class*='listing']")
            for card in cards[:10]:
                try:
                    title_el = card.select_one("p[itemprop='name'], h2, [class*='title']")
                    price_el = card.select_one("p[class*='price'], [class*='Price']")
                    link_el  = card.select_one("a[href]")

                    if not (title_el and price_el and link_el):
                        continue

                    raw_price = price_el.get_text(strip=True).replace("\u202f", "").replace(" ", "")
                    price = int("".join(filter(str.isdigit, raw_price)) or 0)

                    if not (CONFIG["budget_min"] <= price <= CONFIG["budget_max"]):
                        continue

                    href = link_el["href"]
                    full_url = href if href.startswith("http") else f"https://www.avito.ma{href}"

                    results.append({
                        "source":   "Avito.ma",
                        "title":    title_el.get_text(strip=True),
                        "price":    price,
                        "quartier": quartier.replace("-", " ").title(),
                        "url":      full_url,
                        "found_at": datetime.now().strftime("%d/%m %H:%M"),
                    })
                except Exception:
                    continue

        except Exception as e:
            log.warning(f"Avito [{quartier}] — erreur : {e}")

    log.info(f"Avito → {len(results)} annonce(s) dans budget")
    return results


def scrape_mubawab() -> list[dict]:
    """Scrape Mubawab.ma — location appartements Casablanca"""
    results = []
    url = (
        f"https://www.mubawab.ma/fr/sc/casablanca/appartements-a-louer:p:1"
        f"?minPrice={CONFIG['budget_min']}&maxPrice={CONFIG['budget_max']}"
    )
    try:
        r = requests.get(url, headers=HEADERS, timeout=15)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")

        cards = soup.select("li.listingBox, div[class*='listing-card']")
        for card in cards[:15]:
            try:
                title_el = card.select_one("h2, h3, [class*='title']")
                price_el = card.select_one("[class*='price'], [class*='Price']")
                link_el  = card.select_one("a[href]")

                if not (title_el and link_el):
                    continue

                raw_price = (price_el.get_text(strip=True) if price_el else "0")
                price = int("".join(filter(str.isdigit, raw_price.replace(" ", ""))) or 0)

                if price and not (CONFIG["budget_min"] <= price <= CONFIG["budget_max"]):
                    continue

                title_text = title_el.get_text(strip=True).lower()
                quartier_found = next(
                    (q for q in CONFIG["quartiers"] if q.lower() in title_text), "Casablanca"
                )

                href = link_el["href"]
                full_url = href if href.startswith("http") else f"https://www.mubawab.ma{href}"

                results.append({
                    "source":   "Mubawab.ma",
                    "title":    title_el.get_text(strip=True),
                    "price":    price,
                    "quartier": quartier_found.replace("-", " ").title(),
                    "url":      full_url,
                    "found_at": datetime.now().strftime("%d/%m %H:%M"),
                })
            except Exception:
                continue

    except Exception as e:
        log.warning(f"Mubawab — erreur : {e}")

    log.info(f"Mubawab → {len(results)} annonce(s) dans budget")
    return results


def scrape_sarouty() -> list[dict]:
    """Scrape Sarouty.ma — location appartements Casablanca"""
    results = []
    url = (
        f"https://www.sarouty.ma/fr/louer/appartement/casablanca"
        f"?min_price={CONFIG['budget_min']}&max_price={CONFIG['budget_max']}"
    )
    try:
        r = requests.get(url, headers=HEADERS, timeout=15)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")

        cards = soup.select("div[class*='property-card'], article[class*='listing']")
        for card in cards[:15]:
            try:
                title_el = card.select_one("h2, h3, [class*='title']")
                price_el = card.select_one("[class*='price']")
                link_el  = card.select_one("a[href]")

                if not (title_el and link_el):
                    continue

                raw_price = (price_el.get_text(strip=True) if price_el else "0")
                price = int("".join(filter(str.isdigit, raw_price.replace(" ", ""))) or 0)

                if price and not (CONFIG["budget_min"] <= price <= CONFIG["budget_max"]):
                    continue

                href = link_el["href"]
                full_url = href if href.startswith("http") else f"https://www.sarouty.ma{href}"

                results.append({
                    "source":   "Sarouty.ma",
                    "title":    title_el.get_text(strip=True),
                    "price":    price,
                    "quartier": "Casablanca",
                    "url":      full_url,
                    "found_at": datetime.now().strftime("%d/%m %H:%M"),
                })
            except Exception:
                continue

    except Exception as e:
        log.warning(f"Sarouty — erreur : {e}")

    log.info(f"Sarouty → {len(results)} annonce(s) dans budget")
    return results


# ─── TELEGRAM NOTIFICATION ───────────────────────────────────────────────────

def send_telegram(listing: dict):
    token   = CONFIG["telegram_token"]
    chat_id = CONFIG["telegram_chat_id"]

    if not token or not chat_id:
        log.warning("Telegram non configuré — TELEGRAM_TOKEN ou TELEGRAM_CHAT_ID manquant.")
        return

    price_str = f"{listing['price']:,}".replace(",", " ")
    message = (
        f"🏠 *Nouvelle annonce — RentWatch Casa*\n\n"
        f"📍 *{listing['title']}*\n"
        f"💰 {price_str} MAD/mois\n"
        f"📌 Quartier : {listing['quartier']}\n"
        f"🕐 Détectée à : {listing['found_at']}\n"
        f"📡 Source : {listing['source']}\n\n"
        f"🔗 [Voir l'annonce]({listing['url']})"
    )

    try:
        resp = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={
                "chat_id": chat_id,
                "text": message,
                "parse_mode": "Markdown",
                "disable_web_page_preview": False,
            },
            timeout=10
        )
        if resp.status_code == 200:
            log.info(f"✅ Telegram envoyé → {listing['title']}")
        else:
            log.warning(f"Telegram erreur {resp.status_code}: {resp.text}")
    except Exception as e:
        log.error(f"Telegram exception : {e}")


def send_telegram_text(text: str):
    token   = CONFIG["telegram_token"]
    chat_id = CONFIG["telegram_chat_id"]
    if not token or not chat_id:
        return
    try:
        requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            json={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"},
            timeout=10
        )
    except Exception:
        pass


# ─── MAIN SCAN LOOP ──────────────────────────────────────────────────────────

def run_scan():
    log.info("━" * 50)
    log.info(f"🔍 Scan démarré — {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    log.info(f"   Budget : {CONFIG['budget_min']}–{CONFIG['budget_max']} MAD")
    log.info(f"   Quartiers : {', '.join(CONFIG['quartiers'])}")

    seen = load_seen()
    new_count = 0

    all_listings = []
    all_listings += scrape_avito()
    all_listings += scrape_mubawab()
    all_listings += scrape_sarouty()

    for listing in all_listings:
        lid = listing_id(listing["url"])
        if lid not in seen:
            log.info(f"🆕 NOUVELLE ANNONCE : {listing['title']} — {listing['price']} MAD ({listing['source']})")
            send_telegram(listing)
            seen.add(lid)
            new_count += 1
            time.sleep(2)  # évite le spam API

    save_seen(seen)
    log.info(f"✅ Scan terminé — {new_count} nouvelle(s) annonce(s) sur {len(all_listings)} trouvées")
    log.info(f"⏰ Prochain scan dans {CONFIG['scan_interval_min']} minutes")


# ─── ENTRY POINT ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    log.info("🚀 RentWatch Casa — Agent Telegram démarré")
    send_telegram_text(
        "🚀 *RentWatch Casa activé !*\n"
        "Je surveille Avito, Mubawab et Sarouty toutes les 30 min.\n"
        "Tu recevras ici chaque nouvelle annonce entre *3 000 et 6 000 MAD*."
    )
    run_scan()

    schedule.every(CONFIG["scan_interval_min"]).minutes.do(run_scan)

    while True:
        schedule.run_pending()
        time.sleep(60)
